/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ent_Des;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author inteltg
 */
public class Metodos {

    public List<Usuario> usuarios = new ArrayList<>(); //esto no funciona, debe de guardar los datos de nombre y email, no solo nombre

    // Este método es demasiado grande y hace de todo (God Object / Long Method)
    public void registrarUsuario(String nombre, String email, String password, int edad) {
        try { //intentamos crear el usuario
            Usuario user = new Usuario(nombre, email, password, edad);
            usuarios.add(user); //si el usuario es creado exictosamente se guarda

            enviarEmail(usuarios, edad); //metodo para enviar el email si cumple con mayoria de edad
        } catch (Error_Des e) { //si algun dato falla, no se crea al usuario y se muestra el primer error
            System.out.println(e);
        }
    }

    public void enviarEmail(List<Usuario> data, int edad) {
        if (edad >= 18) { //si la edad es 18 o mas, simula el envio de un email
            System.out.println("Enviando correo a " + data.getLast());
        } else { //si no es mayor de edad, si informa
            System.out.println("El usuario es demasiado joven (-18)");
        }
    }

    public void actualizarEmail(List<Usuario> data, String nombre, String nuevoEmail) {
        boolean encontrado = false;
        if (!data.isEmpty()) {
            for (int ini = 0; ini < data.size() && !encontrado; ini++) {
                Usuario user = data.get(ini);
                if (user.getNombre().equalsIgnoreCase(nombre)) {
                    try {
                        user.setEmail(nuevoEmail);
                        encontrado = true;
                    } catch (Error_Des e) {
                        System.out.println(e);
                    }
                }
            }
        } else {
            System.out.println("Error, lista vacia");
        }
    }

    // Método que debería estar en otra clase (Falta de cohesión)
    public void exportarLogs() { //esto no debe de estar aqui y no hace nada
        System.out.println("Exportando logs de actividad a un archivo...");
    }
}
