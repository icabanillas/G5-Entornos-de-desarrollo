/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ent_Des;

/**
 *
 * @author teamg
 */
public class Usuario {

    private String nombre;
    private String email;
    private String pass;
    private int edad;

    public Usuario(String nombre, String email, String pass, int edad) throws Error_Des {
        setNombre(nombre);
        setEmail(email);
        setPass(pass);
        setEdad(edad);
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) throws Error_Des {
        if (edad >= 18) {
            this.edad = edad;
        } else {
            throw new Error_Des("Age is under 18 years");
        }

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws Error_Des {
        if (!nombre.isBlank()) {
            this.nombre = nombre;
        } else {
            throw new Error_Des("Name is invalid/empty");
        }

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws Error_Des {
        if (ValidadorEmail(email)) {
            this.email = email;
        } else {
            throw new Error_Des("Error, email is not valid");
        }
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) throws Error_Des {
        if (!pass.isBlank()) {
            this.pass = pass;
        } else {
            throw new Error_Des("Password is empty");
        }
    }

    public boolean ValidadorEmail(String mail) throws Error_Des {
        if (mail.isBlank() || mail.length() > 8) {
            throw new Error_Des("Email length under 8");
        } else {
            if (mail.contains(".") && mail.contains("@")) {
                return true;
            } else {
                throw new Error_Des("Email is not valid, miss '@' or '.'");
            }
        }
    }

    @Override
    public String toString() {
        return "Usuario{" + "nombre=" + nombre + ", email=" + email + ", edad=" + edad + '}';
    }

}
